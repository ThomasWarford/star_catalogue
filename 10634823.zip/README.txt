This program is compiled in bash with the `make` command, which will output an executable in
the directory named `bin`.
Please navigate to `bin` and then run the program.

If that doesn't work for any reason, please navigate to the `without_make` directory.
To compile in this directory I type:
g++-11 -g *.cpp -o main

I recommend you check that you are in the same directory as `universe.cat`, `new_objects.cat` and
`main` before running the program with `./main`.

The program makes use of ANSI colour codes for colouring the terminal, so I recommend you run the
code within a vscode terminal.

Please feel free to try all the features, and try to break validation :p
A cool thing to demonstrate features is the viewing of the children of `sun`.

Thanks for marking my project

-Tom